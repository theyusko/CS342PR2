./server /shm1 file1 /sem1 &
pid=$!
sleep 2
for i in {1..20}; do ./client /shm1 342 /sem1 | head -c 1M >"result1-$i"; done 
kill -9 $pid
sleep 2

./server /shm2 file2 /sem2 &
pid=$!
sleep 2
rm result2-3
(./client /shm2 keyword /sem2 | head -c 1M >result2-1) && echo "Client 1 finished." >>result2-3 &
c1=$!
(./client /shm2 asdfasa /sem2 | head -c 1M >result2-2) && echo "Client 2 finished." >>result2-3 &
c2=$!
wait $c1 $c2
kill -9 $pid
sleep 2

./server /shm3 file3 /sem3 &
pid=$!
sleep 2
./client /shm3 Even /sem3 | head -c 1M >result3-1 &
c1=$!
./client /shm3 zz /sem3 | head -c 1M >result3-2 &
c2=$!
./client /shm3 Fizz /sem3 | head -c 1M >result3-3 &
c3=$!
./client /shm3 Buzz /sem3 | head -c 1M >result3-4 &
c4=$!
./client /shm3 EvenFizz /sem3 | head -c 1M >result3-5 &
c5=$!
./client /shm3 EvenBuzz /sem3 | head -c 1M >result3-6 &
c6=$!
./client /shm3 FizzBuzz /sem3 | head -c 1M >result3-7 &
c7=$!
wait $c1 $c2 $c3 $c4 $c5 $c6 $c7
kill -9 $pid
