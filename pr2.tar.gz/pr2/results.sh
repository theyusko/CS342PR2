chmod a+x eval.sh
./eval.sh
gedit result*
