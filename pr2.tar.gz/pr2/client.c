#include "shared.h"

// TODO WAIT ON THREAD
// TODO WAIT ON RESULTS
// TODO MAKE SURE ITS THE SAME REQUEST
int main(int argc, char *argv[]) {
    sem_t *sem[N + 1];
    char keyword[MAXWORDNAME];
    int fd, i, j;
    struct stat sbuf;
    void *shm_start;
    struct shared *sdp;
    if (argc != 4) {
        printf("Input format where f is fileName and k is keyword: server <shm_name> <inputfilename> <sem_name>");
        exit(1);
    }

    //Retrieve Arguments
    strcpy(shm_name, argv[1]);
    strcpy(keyword, argv[2]);

    //Init semaphores
    for (i = 0; i < N + 1; i++) {
        char semNo = i + '0';
        strcpy(sem_name[i], argv[3]);
        strcat(sem_name[i], &semNo); //IF THAT CASTING WONT WORK USE SPRINTF
        //sem_unlink(sem_name[i]);

        sem[i] = sem_open(sem_name[i], O_RDWR);
        if (sem[i] < 0) {
            printf("Cannot create semaphore %d \n", i);
            exit(1);
        }
        //printf("sem %d created\n", i);
    }
    for (i = 1; i < argc; i++) {
        if (strlen(argv[i]) > MAXWORDNAME || strlen(argv[i]) == 0) {
            printf("One of the inputs is incorrect. Exiting...\n");
            return 1;
        }
    }

    //Init shared memory
    //shm_unlink(shm_name);

    fd = shm_open(shm_name, O_RDWR, 0600);
    if (fd < 0) {
        perror("can not open shm\n");
        exit(1);
    }

    fstat(fd, &sbuf);

    shm_start = mmap(NULL, sbuf.st_size, PROT_READ | PROT_WRITE,
                     MAP_SHARED, fd, 0);

    if (shm_start < 0) {
        perror("can not map the shm \n");
        exit(1);
    }
    close(fd);
    sdp = (struct shared *) shm_start;
    int done = 0;
    sem_wait(sem[N]);
    for (i = 0; !done; i++) {
        done = !(sdp->result_queue_state[i]);
        if (i == N) {
            printf("Too many clients started. Exiting...\n");
            sem_post(sem[N]); //release
            return 1;
        }
        if (done) {
            sdp->result_queue_state[i] = 1;
            sdp->requestQueue[sdp->requestIn].queueIndex = i;
            strcpy(sdp->requestQueue[sdp->requestIn].keyword, keyword);
            sdp->requestIn = (sdp->requestIn + 1) % N;

        }
    }
    //printf("Client sent request%d", i);
    sem_post(sem[N]);
    i--;
    fflush(stdout);
    while (1) {
        //printf("client read %d\n", sdp->resultQueues[i][sdp->inout[i][OUT]]);
        while ((sdp->inout[i][IN]) % BUFSIZE == sdp->inout[i][OUT]) {}
        sem_wait(sem[i]); //hold result queue i's semaphore
        if(sdp->resultQueues[i][sdp->inout[i][OUT]] == -1) {
            //printf("client releases on sem[%d]\n", i);
            sdp->inout[i][OUT] = (sdp->inout[i][OUT] + 1) % BUFSIZE;
            sem_post(sem[i]);
            break;
        } else {
            printf("%d\n", sdp->resultQueues[i][sdp->inout[i][OUT]]);
            sdp->inout[i][OUT] = (sdp->inout[i][OUT] + 1) % BUFSIZE;
        }
        sem_post(sem[i]);
        //printf("client releases on sem[%d]\n", i);
    }
    fflush(stdout);

    //printf("client waits on sem[%d] after while loop\n", i);
    sem_wait(sem[i]);
    for (j = 0; j < BUFSIZE; j++) {
        sdp->resultQueues[i][j] = 0;
    }

    sem_post(sem[i]);
    //printf("client releases on sem[%d] after while loop\n", i);
    sem_wait(sem[N]);
    sdp->result_queue_state[i] = 0;
    sem_post(sem[N]);

}